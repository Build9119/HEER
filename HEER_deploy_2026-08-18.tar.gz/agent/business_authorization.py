"""Business Authorization Module - D4 Implementation

Authorizes business-level operations based on worker identity and tenant scope.

This module provides a centralized authorization service that operates between
the orchestrator and execution engine, ensuring business isolation while respecting
the frozen constraints of the existing architecture.
"""

from typing import Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class BusinessAuthorization:
    """
    Centralized business authorization service.

    Provides fine-grained authorization for business operations based on:
    - business_id (required)
    - tenant_scope (optional, for tenant isolation)
    - worker_id (required)
    - worker_epoch (required)

    The authorization decision is made before any execution occurs,
    preventing unauthorized business operations.
    """

    def __init__(self):
        # In a real implementation, this would initialize connections to
        # the registry, audit system, and other services
        pass

    def authorize(
        self,
        business_id: str,
        tenant_scope: Optional[str] = None,
        worker_id: str,
        worker_epoch: int
    ) -> Tuple[bool, str]:
        """
        Authorize a business operation based on worker identity and tenant scope.

        Args:
            business_id: Unique identifier for the business
            tenant_scope: Optional tenant scope for tenant isolation
            worker_id: Identifier of the worker to use
            worker_epoch: Epoch of the worker (used for staleness detection)

        Returns:
            Tuple of (allowed: bool, reason: str)
        """
        # 1. Validate required inputs
        if not business_id:
            logger.error("Authorization failed: missing business_id")
            return False, "missing_business_id"

        if not worker_id:
            logger.error("Authorization failed: missing worker_id")
            return False, "missing_worker_id"

        if worker_epoch <= 0:
            logger.error("Authorization failed: invalid worker_epoch")
            return False, "invalid_worker_epoch"

        # 2. Retrieve worker from registry
        # Note: This is a read-only query to the frozen WorkerRegistry
        worker_entry = registry.get(worker_id, tenant_scope=tenant_scope)

        if not worker_entry:
            logger.error(f"Authorization failed: worker {worker_id} not found")
            return False, "worker_not_found"

        # 3. Check worker liveness state
        # Only LIVE workers can be used for execution
        if worker_entry.state != WorkerLivenessState.LIVE:
            logger.error(f"Authorization failed: worker {worker_id} is not LIVE (state: {worker_entry.state})")
            return False, f"worker_{worker_id}_state_{worker_entry.state.value}"

        # 4. Check tenant scope if provided
        if tenant_scope is not None:
            if tenant_scope not in worker_entry.identity.tenant_scope:
                logger.error(f"Authorization failed: worker {worker_id} not in tenant scope {tenant_scope}")
                return False, f"tenant_mismatch: expected {tenant_scope}, got {worker_entry.identity.tenant_scope}"

        # 5. All checks passed - authorization granted
        logger.info(f"Authorization granted for business={business_id}, worker={worker_id}")
        return True, "authorized"


def get_authorization_service() -> BusinessAuthorization:
    """Factory function to get the authorization service instance."""
    return BusinessAuthorization()

</parameter>
</execute_command>